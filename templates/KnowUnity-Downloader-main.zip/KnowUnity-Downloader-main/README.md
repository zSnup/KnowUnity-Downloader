<h1 align="center">KnowUnity PDF Downloader</h1>

`Get PDF Link from the link given by the app or the website`

**How to install locally the project:**

- Clone the repository on your machine.
- Install the Python dependencies by running ```pip install -r requirements.txt```.
- Launch the web server by running ```python app.py```.
- Go to http://localhost:5000/ in your browser.
- Enter a URL in the form and press the "Get PDF Link!" button.